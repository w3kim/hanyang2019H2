# Virtual Dev Environment using Vagrant

```
$ vagrant up
$ vagrant ssh
vagrant@ubuntu-xenial:~$ 
```

## For Windows users

Make sure you run CMD with admin privilege so you can create symlinks. Use Windows+R to open the "Run" box, type "cmd", and then press Ctrl+Shift+Enter to run as an administrator.