# Project

## Count App Project Setup
```
$ npx create-react-app count
$ cd count
$ npm install caver-js
$ rm -f src/*
$ 
```
